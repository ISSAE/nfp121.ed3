interface CounterObserver
{

public void counterHasChanged(Counter ctr);

}
