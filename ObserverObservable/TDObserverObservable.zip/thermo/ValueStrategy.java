interface ValueStrategy
{	public void set(double d);
	public double get();
}

